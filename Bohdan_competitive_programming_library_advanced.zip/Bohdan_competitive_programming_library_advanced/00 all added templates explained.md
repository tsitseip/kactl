# All added templates: what they do, when to use them, and examples

This guide covers:

- **Part I:** 34 templates added in the first expansion.
- **Part II:** 40 templates added in the advanced expansion.
- **Part III:** direct comparisons between similar templates.

The examples are recognition examples: they show what a problem using the technique may look like. They are not full problem statements or implementation tutorials.

---

# Part I — First 34 additions

## Graph theory

### 1. Dinic maximum flow

**What it does:** Finds the maximum flow from source `s` to sink `t` in a directed capacitated graph.

**Recognize it when:** Objects or resources must pass through edges with capacities, and flow can split across several paths.

**Example:** There are factories, warehouses, and roads with daily capacities. Find the maximum number of units that can reach the destination.

**Difference:** Dinic optimizes only the amount of flow. Use **min-cost max-flow** when every unit sent through an edge also has a cost.

---

### 2. Heavy-light decomposition (HLD)

**What it does:** Splits a static tree into `O(log n)` heavy paths so path and subtree operations can be handled with a segment tree.

**Recognize it when:** The tree topology never changes, but there are updates and queries on paths such as `u-v`.

**Example:** Change the value of one vertex and query the maximum value on the path between two vertices.

**Difference:** HLD is for a **static tree**. A **link-cut tree** is needed when edges are linked and cut dynamically.

---

### 3. Tarjan strongly connected components

**What it does:** Divides a directed graph into maximal groups where every vertex is reachable from every other vertex.

**Recognize it when:** Directed cycles should be compressed, or the problem asks about mutual reachability.

**Example:** Compress all mutually reachable cities into components and then solve a DP on the resulting DAG.

**Difference:** SCC is the general decomposition. **2-SAT** uses SCC on an implication graph for Boolean clauses.

---

### 4. Centroid decomposition

**What it does:** Recursively removes a centroid, producing a decomposition tree of depth `O(log n)`.

**Recognize it when:** Queries depend on distances to changing sets of marked vertices in a static tree.

**Example:** Toggle vertices red/white and query the distance from `v` to the closest red vertex.

**Difference:** HLD is usually better for aggregates **along one path**. Centroid decomposition is often better for distances between a vertex and a dynamic global set.

---

### 5. Min-cost max-flow

**What it does:** Sends flow while minimizing total cost; it may find either maximum flow of minimum cost or a requested amount of flow.

**Recognize it when:** The problem contains capacities, assignments, and a cost or profit per chosen connection.

**Example:** Assign students to projects, each project having capacity and each assignment having a dissatisfaction cost.

**Difference:** Use **Hungarian** for a dense one-to-one assignment matrix without general network capacities. Use **Dinic** if costs do not matter.

---

## Data structures

### 6. DSU on tree / small-to-large

**What it does:** Computes subtree answers by keeping the largest child’s data and merging smaller child data into it.

**Recognize it when:** Every vertex needs an answer about all values in its subtree, and insert/remove operations are easy.

**Example:** For every vertex, count how many colors occur most frequently in its subtree.

**Difference:** It is an offline/static-tree method. **Centroid decomposition** is generally for dynamic distance queries, while **rerooting DP** computes root-dependent DP states.

---

### 7. Rollback DSU

**What it does:** A disjoint-set union structure that can undo merges by restoring an earlier snapshot.

**Recognize it when:** Connectivity states must be explored recursively or over time, but normal path compression would destroy rollback information.

**Example:** Add edges while entering a segment-tree-over-time node, answer queries, then undo those edges while leaving the node.

**Difference:** Rollback DSU is the component used inside **offline dynamic connectivity**. By itself it does not schedule edge lifetimes.

---

### 8. Wavelet tree

**What it does:** Supports static subarray order-statistic and frequency queries.

**Recognize it when:** Queries ask for kth smallest, count `<= x`, or count in a value range inside `[l,r)`.

**Example:** For each interval, return its median and the number of values between 10 and 100.

**Difference:** **Wavelet matrix** provides similar operations with a more iterative bit-level layout and often cleaner handling of a fixed integer domain.

---

## Segment trees

### 9. Iterative segment tree: sum and maximum

**What it does:** A compact bottom-up segment tree for point updates and range queries.

**Recognize it when:** Only point changes and ordinary associative range queries are needed.

**Example:** Update `a[p]`, then query the sum or maximum on `[l,r)`.

**Difference:** It is simpler and usually faster than recursive lazy trees, but it does not directly support range updates.

---

### 10. Lazy arithmetic-progression update + sum

**What it does:** Adds an arithmetic progression to a range and queries range sums.

**Recognize it when:** An update adds values such as `x, x+d, x+2d, ...` over consecutive indices.

**Example:** For `[l,r)`, add `1` at `l`, `2` at `l+1`, and so on; later query interval sums.

**Difference:** Ordinary lazy add-sum applies one constant to the whole range. This template must store enough lazy information to reconstruct a position-dependent addition.

---

### 11. Mergeable dynamic segment tree

**What it does:** Represents sparse frequency/sum distributions and can merge two trees efficiently.

**Recognize it when:** Each subtree or component owns a sparse value-frequency structure, and structures must be combined.

**Example:** Every tree vertex contributes one color; merge child structures to obtain frequency information for the parent.

**Difference:** Unlike a persistent tree, merging normally combines ownership and is not intended to preserve every old version.

---

### 12. Persistent lazy segment tree: add + sum

**What it does:** Supports range addition and range-sum queries while retaining old versions.

**Recognize it when:** Range updates create new historical states, and later queries refer to any earlier version.

**Example:** Version `i` applies an update to version `p`; queries ask for the sum in version `7` even after newer versions exist.

**Difference:** An ordinary persistent point-update tree clones only a root-to-leaf path. Persistent lazy propagation is harder because delayed range tags must also be copied correctly.

---

### 13. Segment tree beats: `chmin`, add, sum

**What it does:** Supports range addition, range `chmin` (`a[i]=min(a[i],x)`), and sum queries.

**Recognize it when:** Updates cap only values above a threshold, mixed with sums or additions.

**Example:** Add 5 to a range, cap all values there at 20, and query the sum.

**Difference:** The **full segment tree beats** addition also supports `chmax`, minimum, and maximum queries.

---

## Dynamic-programming optimizations

### 14. SOS DP

**What it does:** Computes sums or other transforms over all submasks or supermasks in `O(n2^n)`.

**Recognize it when:** States are indexed by bitmasks and the transition involves every submask/supermask.

**Example:** For every mask `S`, compute the total frequency of all masks `T` such that `T subset S`.

**Difference:** **Subset convolution** handles a more difficult split `S=T union (S\T)` with multiplication of contributions; SOS DP is simpler.

---

### 15. Aliens trick

**What it does:** Replaces a constraint such as “use exactly `k` groups” with a penalty per group and binary-searches that penalty.

**Recognize it when:** A DP can optimize cost plus `lambda * number_of_groups`, and the selected number of groups changes monotonically with `lambda`.

**Example:** Split an array into exactly `k` segments while minimizing total segment cost.

**Difference:** **WQS binary search** is essentially the same family/name. The main issue is whether the final exact-`k` value can be recovered correctly.

---

### 16. Monotone convex hull trick

**What it does:** Maintains lines and answers min/max queries in amortized `O(1)` when slopes and query `x` values arrive monotonically.

**Recognize it when:** A DP becomes `dp[i]=min_j(m_j*x_i+b_j)` and both insertion slopes and query coordinates are ordered.

**Example:** Prefix-based DP where `x_i` is nondecreasing and each new line has a monotone slope.

**Difference:** Use a **dynamic line container** when order is arbitrary, or a **Li Chao tree** when coordinates/order do not satisfy monotonicity.

---

### 17. Divide-and-conquer DP optimization

**What it does:** Reduces transitions of the form  
`dp[g][i] = min_{j<i}(prev[j] + cost(j+1,i))`  
when the optimal split positions are monotone.

**Recognize it when:** The DP partitions a prefix into groups and you can prove `opt[g][i] <= opt[g][i+1]`.

**Example:** Partition an array into `k` groups minimizing a Monge-like interval cost.

**Difference:** **Knuth** is for interval DP with a stronger property and often reaches `O(n^2)`. **SMAWK** finds row optima of a totally monotone matrix.

---

### 18. Knuth optimization

**What it does:** Optimizes interval DP from `O(n^3)` to `O(n^2)` when  
`opt[l][r-1] <= opt[l][r] <= opt[l+1][r]`.

**Recognize it when:** The recurrence splits an interval at `k`, and interval costs satisfy quadrangle/Monge conditions.

**Example:** Optimal merging or alphabetic tree-style interval costs.

**Difference:** Divide-and-conquer optimization is usually for layered prefix DP; Knuth is for interval DP.

---

## Geometry

### 19. Convex hull

**What it does:** Returns the smallest convex polygon containing all input points.

**Recognize it when:** Interior points do not matter for extreme distance, support line, perimeter, or containment tasks.

**Example:** Remove all non-extreme points before finding the farthest pair.

**Difference:** Convex hull is often preprocessing for **rotating calipers**, **point in convex polygon**, or **Minkowski sum**.

---

### 20. General 2D geometry primitives

**What it does:** Provides reusable point, vector, dot/cross product, orientation, line, segment, and intersection operations.

**Recognize it when:** A geometry problem needs reliable basic operations rather than one specific algorithm.

**Example:** Check whether two segments intersect and compute the intersection of two nonparallel lines.

**Difference:** This is infrastructure. Algorithms such as convex hull and half-plane intersection are built on top of it.

---

### 21. Minkowski sum

**What it does:** Computes `{a+b | a in A, b in B}` for two convex polygons in linear time after normalization.

**Recognize it when:** Two independently movable shapes/point sets are combined by vector addition.

**Example:** Robot shape plus obstacle shape, or all possible sums of one point from each convex polygon.

**Difference:** It is not the union of polygons. It adds every point of one set to every point of the other.

---

### 22. Point in convex polygon

**What it does:** Tests whether a point lies inside/on a convex polygon in `O(log n)`.

**Recognize it when:** There are many point-containment queries against one fixed convex polygon.

**Example:** Determine which query locations lie inside a convex restricted zone.

**Difference:** A general polygon often needs ray casting in `O(n)`; convexity enables binary search.

---

## Strings

### 23. Aho–Corasick

**What it does:** Builds a trie with failure links to match many patterns simultaneously in linear time in the text plus matches.

**Recognize it when:** Many fixed patterns must be searched in one or many texts.

**Example:** Count occurrences of 100,000 dictionary words in one long text.

**Difference:** A prefix trie alone cannot efficiently recover after mismatch. A suffix automaton describes all substrings of one text rather than matching a pattern dictionary.

---

### 24. Double rolling hash

**What it does:** Computes substring hashes under two moduli to compare substrings quickly with very low collision probability.

**Recognize it when:** Many substring-equality, palindrome, or lexicographic-comparison queries are needed and deterministic suffix structures are unnecessary.

**Example:** Check whether `s[l1..r1)` equals `s[l2..r2)` in `O(1)`.

**Difference:** Hashing is probabilistic. Suffix array/automaton and Z/KMP methods can give deterministic answers for their supported operations.

---

### 25. Suffix automaton

**What it does:** A compact automaton representing all substrings of one string.

**Recognize it when:** You need counts, existence, lengths, or lexicographic information about distinct substrings.

**Example:** Count distinct substrings or find the longest common substring of two strings.

**Difference:** A suffix array sorts suffixes and is strong for LCP/order queries. A suffix automaton is naturally online and transition-based.

---

## Algebra and number theory

### 26. Berlekamp–Massey + kth term

**What it does:** Infers the shortest linear recurrence from initial sequence terms, then computes a faraway term.

**Recognize it when:** You can generate enough initial terms modulo a prime, but `k` may be enormous.

**Example:** Generate the first 200 values of a combinatorial sequence and find term `10^18`.

**Difference:** **Bostan–Mori** computes coefficients of a known rational generating function. Berlekamp–Massey first discovers the recurrence.

---

### 27. CRT for non-coprime moduli

**What it does:** Combines congruences even when moduli are not pairwise coprime, or detects inconsistency.

**Recognize it when:** Conditions are `x = a_i (mod m_i)` with shared factors between moduli.

**Example:** Solve `x=2 mod 6` and `x=8 mod 14`.

**Difference:** The simple CRT formula requiring modular inverses assumes coprime moduli.

---

### 28. Gaussian elimination modulo a prime

**What it does:** Solves linear systems, determines rank, and detects no/one/multiple solutions over a finite field.

**Recognize it when:** Unknowns satisfy linear equations modulo a prime.

**Example:** Recover variables from XOR-like or modular linear constraints.

**Difference:** Floating-point Gaussian elimination is for real-valued systems. This one uses modular inverses.

---

### 29. `modint`

**What it does:** Wraps modular arithmetic in a type with overloaded `+,-,*,/,power,inverse`.

**Recognize it when:** A solution contains many modular operations and manual normalization would be error-prone.

**Example:** Write polynomial or combinatorial code with expressions that resemble ordinary arithmetic.

**Difference:** It is a utility, not an algorithm. Division is valid only when the divisor is invertible modulo `mod`.

---

### 30. Miller–Rabin + Pollard–Rho

**What it does:** Tests 64-bit primality and factors large composite 64-bit integers.

**Recognize it when:** Values are too large for trial division or a sieve, often up to `10^18`.

**Example:** Factor a 60-bit number into primes.

**Difference:** A smallest-prime-factor sieve is faster when all values are bounded by a manageable maximum such as `10^7`.

---

## FFT and polynomials

### 31. FWHT: XOR/AND/OR convolution

**What it does:** Performs convolutions where mask indices combine by XOR, AND, or OR.

**Recognize it when:** The result is  
`c[k] = sum a[i]b[j]` over pairs with `i XOR j=k`, or similarly AND/OR.

**Example:** Count pairs of masks whose XOR equals each target mask.

**Difference:** FFT/NTT handles ordinary index addition `i+j`; FWHT handles bitwise operations.

---

### 32. Clean NTT

**What it does:** Multiplies polynomials exactly modulo an NTT-friendly prime such as `998244353`.

**Recognize it when:** Coefficients are modular and exact convolution is required.

**Example:** Multiply two polynomials of degree `2e5` modulo `998244353`.

**Difference:** Complex FFT uses floating point. Arbitrary-mod convolution is needed when the target modulus is not NTT-friendly.

---

### 33. Arbitrary-modulus convolution

**What it does:** Multiplies polynomials modulo a chosen modulus by using several NTT primes and CRT reconstruction.

**Recognize it when:** You need convolution modulo `1e9+7` or another modulus without a suitable large root of unity.

**Example:** Multiply degree-`1e5` polynomials modulo `1,000,000,007`.

**Difference:** It is slower than one clean NTT because several transforms are required.

---

### 34. Basic formal power series (FPS)

**What it does:** Treats polynomials as truncated infinite series and supports operations such as inverse, logarithm, and exponential modulo `x^n`.

**Recognize it when:** The problem asks for coefficients of functions like `1/f(x)`, `log f(x)`, or `exp f(x)`.

**Example:** Given `f(0)=1`, compute the first `n` coefficients of `log f(x)`.

**Difference:** The advanced FPS file adds square root, integer power, and fast polynomial division.

---

# Part II — Advanced 40 additions

## Graph theory

### 35. Directed MST / Chu–Liu–Edmonds

**What it does:** Finds a minimum-cost directed spanning arborescence rooted at a chosen source.

**Recognize it when:** Every non-root vertex must choose one incoming directed edge, and all vertices must become reachable from the root.

**Example:** Select the cheapest directed communication links so the capital can reach every city.

**Difference:** Kruskal/Prim are only for undirected graphs.

---

### 36. Dominator tree

**What it does:** In a directed graph rooted at `s`, finds which vertex must occur on every path from `s` to another vertex.

**Recognize it when:** The question asks for unavoidable checkpoints from one source.

**Example:** In a control-flow graph, determine which blocks must execute before block `v`.

**Difference:** Articulation points are for undirected connectivity. Dominators are source-dependent and directed.

---

### 37. General matching / Blossom

**What it does:** Finds maximum matching in an arbitrary undirected graph, including odd cycles.

**Recognize it when:** Pairing is required but the graph is not bipartite.

**Example:** Pair compatible students when triangles of mutual compatibility may exist.

**Difference:** Kuhn/Hopcroft–Karp are simpler and faster for bipartite graphs only.

---

### 38. Gomory–Hu tree

**What it does:** Encodes every pairwise minimum cut of an undirected weighted graph in one tree.

**Recognize it when:** Many `mincut(u,v)` queries are asked on one fixed undirected graph.

**Example:** For many city pairs, find the minimum capacity that must be removed to disconnect them.

**Difference:** It performs `n-1` source-sink max flows. Stoer–Wagner returns only the single global minimum cut.

---

### 39. Link-cut tree

**What it does:** Maintains a dynamic forest with link, cut, connectivity, and path aggregate operations.

**Recognize it when:** The forest topology changes online.

**Example:** Add/remove roads while querying the maximum edge weight between two connected vertices.

**Difference:** HLD assumes a static topology. Link-cut trees are more flexible but more complex and have larger constants.

---

### 40. Offline dynamic connectivity

**What it does:** Answers add-edge, remove-edge, and connectivity queries by combining edge-active intervals, a segment tree over time, and rollback DSU.

**Recognize it when:** Edges are deleted, but all operations can be read before answering.

**Example:** Process `+ u v`, `- u v`, and `? u v`.

**Difference:** It is offline. Link-cut trees can work online only when the maintained graph is a forest; general dynamic graph connectivity is harder.

---

### 41. Stoer–Wagner global min-cut

**What it does:** Finds the minimum cut over every nonempty partition of an undirected weighted graph.

**Recognize it when:** There is no specified source and sink.

**Example:** Find the cheapest way to split a network into two parts.

**Difference:** Dinic computes one `s-t` cut. Gomory–Hu supports all pairwise cuts after heavier preprocessing.

---

### 42. Virtual tree

**What it does:** Compresses a query’s marked vertices and necessary LCAs into an `O(k)` tree.

**Recognize it when:** The original tree is huge, but each query mentions only a small set of vertices.

**Example:** For 30 marked vertices in a tree of size `2e5`, compute the total length of their connecting subtree.

**Difference:** HLD answers path operations on the whole tree. A virtual tree reduces per-query work to the relevant vertices.

---

## Data structures

### 43. Disjoint sparse table

**What it does:** Answers static range queries in `O(1)` for any associative operation, including non-idempotent operations.

**Recognize it when:** The array never changes and the operation is associative but overlapping blocks cannot be reused.

**Example:** Query an ordered product of matrices on `[l,r)`.

**Difference:** Ordinary sparse table needs an idempotent operation such as min/max/gcd for its overlapping-query trick.

---

### 44. Dynamic line container

**What it does:** Inserts lines and queries the best value at arbitrary `x`, usually in `O(log n)`.

**Recognize it when:** CHT form exists but slopes and query coordinates arrive in no useful order.

**Example:** `dp[i]=max_j(m_j*x_i+b_j)` online with arbitrary `m_j` and `x_i`.

**Difference:** Monotone CHT is faster when ordering conditions hold. Li Chao is often easier over a known coordinate domain.

---

### 45. Li Chao tree with segment insertion

**What it does:** Inserts a line that is valid only on a chosen x-interval.

**Recognize it when:** Each candidate function has both a linear value and an active time/coordinate interval.

**Example:** Offer `j` has profit `k_j*x+b_j` only for `L_j<=x<R_j`.

**Difference:** Standard Li Chao inserts a line over the entire domain.

---

### 46. Persistent binary trie

**What it does:** Keeps trie versions for prefixes, enabling XOR queries on any subarray by subtracting version counts.

**Recognize it when:** Queries combine index ranges with XOR optimization or XOR counting.

**Example:** Find `max(a[i] XOR x)` for `L<=i<R`.

**Difference:** A normal binary trie handles the current global set only; persistence isolates subarrays or historical versions.

---

### 47. Slope trick

**What it does:** Represents a convex piecewise-linear DP function using heaps and supports adding absolute-value/hinge penalties.

**Recognize it when:** The DP state is a convex function and transitions add `|x-a|`, `max(0,x-a)`, or constrain movement.

**Example:** Choose a nondecreasing sequence minimizing `sum |x_i-a_i|`.

**Difference:** CHT optimizes minima of lines. Slope trick maintains a convex function whose derivative changes at breakpoints.

---

### 48. Wavelet matrix

**What it does:** Supports static range kth, rank, and frequency queries through a bitwise layered representation.

**Recognize it when:** Many static subarray order-statistic queries are required.

**Example:** Query kth smallest and count values in `[A,B)` inside `[l,r)`.

**Difference:** Same problem family as wavelet tree; wavelet matrix is often more cache-friendly and avoids recursive value intervals.

---

## Advanced segment trees

### 49. Dynamic lazy segment tree: range add + sum

**What it does:** Creates nodes only when touched while supporting range addition and range sums on a huge coordinate interval.

**Recognize it when:** Coordinates may reach `10^18`, updates cover intervals, and compression is inconvenient.

**Example:** Add weight to every integer coordinate in `[l,r)` and query sums later.

**Difference:** Your earlier dynamic segment trees support point updates; this one also has lazy range updates.

---

### 50. Historical maximum segment tree

**What it does:** Tracks both current values and the greatest values ever reached after a sequence of updates.

**Recognize it when:** Queries ask for a maximum over time, not only in the current array.

**Example:** Range scores receive positive and negative additions; ask the maximum current score and maximum score ever achieved.

**Difference:** An ordinary lazy max tree forgets past peaks after negative updates.

---

### 51. Full segment tree beats

**What it does:** Supports range add, `chmin`, `chmax`, and sum/min/max queries.

**Recognize it when:** Both upper and lower clipping operations occur together with aggregate queries.

**Example:** Apply `a[i]=min(a[i],10)`, `a[i]=max(a[i],3)`, add 5, and query sums.

**Difference:** The first beats template only supports `chmin + add + sum`; the full version supports both clipping directions and more queries.

---

## DP and tree optimization

### 52. SMAWK

**What it does:** Finds all row minima of a totally monotone implicit matrix in linear evaluations.

**Recognize it when:** A transition matrix is Monge/totally monotone and every row optimum is needed.

**Example:** Optimize a DP whose candidate-cost matrix has monotone row minima.

**Difference:** Divide-and-conquer optimization uses monotone opt indices and is often easier to apply. SMAWK is theoretically stronger but requires a total-monotonicity proof.

---

### 53. WQS binary search

**What it does:** Uses a penalty parameter to turn an exact-count optimization into a simpler unconstrained optimization.

**Recognize it when:** The number of selected groups/items is monotone in penalty `lambda`.

**Example:** Pick exactly `k` edges/components/segments minimizing total cost.

**Difference:** This is the same main technique family as the earlier **Aliens trick**. Keep one preferred implementation after understanding tie-breaking and exact-`k` recovery.

---

### 54. Bitset LCS

**What it does:** Computes LCS length with machine-word parallelism, often around 64 times faster than ordinary quadratic DP.

**Recognize it when:** Strings are too long for `O(nm)` but only the LCS length is needed.

**Example:** Two strings of length about `2e4`.

**Difference:** It is specialized for LCS and depends on bitset operations; it is not a general DP optimizer.

---

### 55. Generic rerooting DP

**What it does:** Computes a DP answer for every possible root in linear time using upward and downward contributions.

**Recognize it when:** Each vertex needs the result that would arise if the tree were rooted there.

**Example:** Compute the sum of distances from every vertex to every other vertex.

**Difference:** DSU on tree answers subtree-set statistics. HLD answers paths. Rerooting transfers a tree DP across every edge.

---

## Geometry

### 56. Half-plane intersection

**What it does:** Intersects directed half-planes and returns their convex feasible polygon.

**Recognize it when:** Constraints are linear inequalities in two variables or repeated line clipping.

**Example:** Find the feasible region satisfying all `a_i*x+b_i*y<=c_i`.

**Difference:** Convex hull encloses points; half-plane intersection intersects constraints/regions.

---

### 57. Minimum enclosing circle

**What it does:** Finds the smallest circle containing all points in expected linear time.

**Recognize it when:** One center and minimum required radius must cover every point.

**Example:** Place a radio station to cover all villages with minimum radius.

**Difference:** Convex hull may reduce intuition, but the optimal circle can be determined by two or three boundary points.

---

### 58. Rotating calipers diameter

**What it does:** Finds the farthest pair of vertices of a convex polygon in linear time.

**Recognize it when:** You need the diameter of a point set.

**Example:** Build the convex hull, then find the maximum squared distance between any pair.

**Difference:** Convex hull is the preprocessing; rotating calipers is the optimization over the hull.

---

## Strings

### 59. Duval / Lyndon factorization / minimum rotation

**What it does:** Decomposes a string into Lyndon words and finds its lexicographically minimum cyclic rotation in linear time.

**Recognize it when:** Rotations, Lyndon decomposition, or special periodicity arguments appear.

**Example:** Find the smallest rotation of `baca`, which is `abac`.

**Difference:** Booth’s algorithm also finds minimum rotation; Duval additionally produces Lyndon factorization.

---

### 60. Palindromic tree / Eertree

**What it does:** Stores every distinct palindromic substring as one node while processing a string online.

**Recognize it when:** Distinct palindromes, occurrence counts, or palindromic suffix transitions are needed.

**Example:** Count all distinct palindromes and occurrences of each.

**Difference:** Manacher gives palindrome radii at every center but does not explicitly build the set of distinct palindromes.

---

## Algebra and optimization

### 61. Hungarian assignment

**What it does:** Finds a minimum-cost one-to-one assignment in a rectangular cost matrix.

**Recognize it when:** Every worker chooses one distinct job and total pair cost is minimized.

**Example:** Assign `n` workers to `m` jobs.

**Difference:** Min-cost max-flow handles more general capacities and network constraints; Hungarian is more specialized and usually faster.

---

### 62. Matrix-tree theorem

**What it does:** Counts spanning trees using a determinant of a Laplacian minor.

**Recognize it when:** The problem asks for the number of spanning trees, often modulo a prime.

**Example:** Count spanning trees of a multigraph modulo `998244353`.

**Difference:** MST algorithms minimize weight; matrix-tree theorem counts all spanning trees.

---

### 63. Rollback XOR basis

**What it does:** Maintains a linear basis over `GF(2)` with snapshots and undo operations.

**Recognize it when:** Values are active on time intervals and queries ask for maximum subset XOR.

**Example:** Add each value over its active time interval in a segment tree over time, query, then rollback.

**Difference:** The ordinary XOR basis only grows; the rollback version can return to earlier states.

---

## Number theory

### 64. Du Jiao sieve

**What it does:** Computes prefix sums of multiplicative functions such as phi and Möbius for very large `n`.

**Recognize it when:** `n` is around `10^10`–`10^12` and a formula needs `sum_{i<=n} phi(i)` or `sum mu(i)`.

**Example:** Evaluate a gcd-counting formula using summatory phi.

**Difference:** A normal sieve precomputes every value up to `n`; Du Jiao groups equal quotients and memoizes large arguments.

---

### 65. Tonelli–Shanks

**What it does:** Solves `x^2 = a (mod p)` for odd prime `p`, or reports no root.

**Recognize it when:** A modular square root is required.

**Example:** Find square roots of 10 modulo 13.

**Difference:** Modular exponentiation alone works only for certain prime congruence classes, while Tonelli–Shanks handles general odd primes.

---

### 66. Divisor zeta and Möbius transforms

**What it does:** Performs transforms over divisibility relationships and enables gcd/lcm convolutions.

**Recognize it when:** Arrays are indexed by integers and pairs combine through gcd or lcm.

**Example:** Compute `c[g]=sum_{gcd(i,j)=g}a[i]b[j]`.

**Difference:** SOS DP performs analogous transforms on subset inclusion rather than divisibility.

---

### 67. Extended BSGS discrete logarithm

**What it does:** Solves `a^x=b (mod m)` even when `a` and `m` are not coprime.

**Recognize it when:** The unknown is an exponent modulo a possibly composite modulus.

**Example:** Find the smallest `x` such that repeated multiplication by `a` reaches `b`.

**Difference:** Ordinary BSGS assumes the coprime group case.

---

### 68. Floor sum

**What it does:** Computes  
`sum_{0<=i<n} floor((a*i+b)/m)`  
in logarithmic time.

**Recognize it when:** Counting lattice points or manipulating repeated floor divisions.

**Example:** Count integer points under a rational line.

**Difference:** Quotient grouping handles sums where `floor(n/i)` is constant on intervals; floor-sum handles an affine numerator.

---

### 69. Primitive root modulo a prime

**What it does:** Finds a generator of the nonzero residues modulo prime `p`.

**Recognize it when:** Roots of unity, cyclic multiplicative groups, or discrete logarithm constructions are needed.

**Example:** Find a primitive root for an NTT-friendly prime.

**Difference:** A primitive root generates the whole multiplicative group; an NTT root is then derived for a particular power-of-two length.

---

## FFT and polynomials

### 70. Bostan–Mori

**What it does:** Finds coefficient `[x^k]P(x)/Q(x)` in near-linear polynomial time times `log k`.

**Recognize it when:** A linear recurrence/generating function is known and the requested index is huge.

**Example:** Find term `10^18` of a recurrence of degree 500.

**Difference:** Berlekamp–Massey discovers a recurrence from terms. Bostan–Mori uses a known rational generating function and is excellent for huge `k`.

---

### 71. Taylor shift

**What it does:** Converts coefficients of `f(x)` into coefficients of `f(x+c)` using convolution.

**Recognize it when:** A polynomial must be re-centered around another origin.

**Example:** Given `f(x)`, compute all coefficients after replacing `x` by `x+5`.

**Difference:** Multipoint evaluation computes values at many points; Taylor shift computes the entire shifted polynomial.

---

### 72. Advanced formal power series

**What it does:** Extends the basic FPS implementation with square root, integer power, and fast polynomial division/remainder.

**Recognize it when:** The required operation is more than inverse/log/exp.

**Example:** Compute `f(x)^k mod x^n` or find `g(x)` satisfying `g(x)^2=f(x)`.

**Difference:** It depends on clean NTT and basic FPS routines.

---

### 73. Multipoint evaluation and interpolation

**What it does:** Evaluates one polynomial at many points or reconstructs a polynomial from many distinct point-value pairs.

**Recognize it when:** Both polynomial degree and number of query points are large.

**Example:** Evaluate a degree-`2e5` polynomial at `2e5` points.

**Difference:** Horner is `O(n)` per point. Multipoint evaluation uses a product/remainder tree for near-linear total complexity.

---

### 74. Subset convolution

**What it does:** Computes  
`c[S]=sum_{T subset S}a[T]b[S\T]`  
in `O(n^2 2^n)`.

**Recognize it when:** A set must be split into two disjoint parts and contributions from both parts are multiplied.

**Example:** For every vertex subset, combine the number of structures on `T` with structures on its complement inside `S`.

**Difference:** SOS DP aggregates over submasks; subset convolution combines two arrays over complementary submasks.

---

# Part III — Direct comparison cheat sheet

## Tree techniques

| Technique | Tree changes? | Main query type | Typical use |
|---|---:|---|---|
| HLD | No | path/subtree aggregate | updates and sums/max on `u-v` |
| Link-cut tree | Yes | dynamic path aggregate | online link/cut in a forest |
| Centroid decomposition | No | distance to dynamic sets | closest marked vertex |
| Virtual tree | No | per-query small marked set | DP on only `k` relevant vertices |
| DSU on tree | No | subtree frequency/statistics | colors or values in every subtree |
| Rerooting DP | No | answer for every root | distances or root-dependent DP |

## Line/CHT structures

| Technique | Line insertion | Query `x` | Restricted interval? | Typical complexity |
|---|---|---|---:|---:|
| Monotone CHT | monotone slopes | monotone | No | amortized `O(1)` |
| Dynamic line container | arbitrary | arbitrary | No | `O(log n)` |
| Standard dynamic Li Chao | arbitrary | arbitrary | No | `O(log X)` |
| Segment Li Chao | arbitrary | arbitrary | Yes | about `O(log^2 X)` |

Use the simplest structure whose assumptions are guaranteed.

## Static range order-statistic structures

| Technique | Operations | Notes |
|---|---|---|
| Wavelet tree | kth/count/rank | recursive value partition |
| Wavelet matrix | kth/count/rank | iterative bit layers; often cleaner/faster |
| Persistent segment tree | kth/count using versions | flexible when prefix versions already fit |
| Persistent binary trie | XOR max/count/order | specialized for bitwise XOR queries |

## Segment-tree variants

| Template | Updates | Queries | Key reason to use |
|---|---|---|---|
| Iterative segment tree | point | sum/max/etc. | smallest constants |
| Ordinary lazy | range add/assign | sum/max/etc. | standard interval updates |
| AP lazy | arithmetic progression | sum | update depends on index |
| Dynamic lazy | range add | sum | huge sparse coordinate domain |
| Persistent lazy | range add | sum by version | historical range states |
| Mergeable dynamic | merge trees | frequencies/sums | combine subtree/component data |
| Beats partial | add + chmin | sum | upper clipping |
| Beats full | add + chmin + chmax | sum/min/max | both clipping directions |
| Historical maximum | range updates | current and all-time max | history matters |

## Flow, cut, and matching

| Technique | Problem |
|---|---|
| Dinic | maximum `s-t` flow / one `s-t` min-cut |
| Min-cost max-flow | flow with per-unit costs |
| Hungarian | dense one-to-one assignment |
| Kuhn/Hopcroft–Karp | bipartite maximum matching |
| Blossom | general undirected maximum matching |
| Stoer–Wagner | one global undirected min-cut |
| Gomory–Hu | all pairwise undirected min-cuts |
| Directed MST | cheapest rooted directed arborescence |

## DP optimization

| Technique | Required shape |
|---|---|
| Monotone CHT | linear transition and monotone slopes/queries |
| Dynamic CHT/Li Chao | linear transition without monotonicity |
| Divide-and-conquer DP | monotone optimal split by destination |
| Knuth | interval DP with stronger quadrangle conditions |
| SMAWK | totally monotone implicit matrix |
| Aliens/WQS | exact count handled through a monotone penalty |
| SOS DP | aggregate over submasks/supermasks |
| Subset convolution | split one mask into two complementary parts |
| Slope trick | convex piecewise-linear DP state |

## String structures

| Technique | Best for |
|---|---|
| Aho–Corasick | many patterns in text |
| Rolling hash | quick substring equality |
| Suffix automaton | all distinct substrings / online transitions |
| Suffix array | suffix order, LCP, lexicographic queries |
| Manacher | palindrome radius at every center |
| Eertree | all distinct palindromes and their links |
| Duval | Lyndon decomposition and minimum rotation |

## Polynomial tools

| Technique | Use |
|---|---|
| Complex FFT | ordinary integer convolution with rounding |
| Clean NTT | exact convolution modulo NTT prime |
| Arbitrary-mod convolution | exact convolution modulo another modulus |
| Basic FPS | inverse/log/exp |
| Advanced FPS | sqrt/power/division |
| Berlekamp–Massey | infer recurrence from initial terms |
| Bostan–Mori | huge coefficient of known rational generating function |
| Multipoint evaluation | one polynomial at many points |
| Taylor shift | coefficients of `f(x+c)` |
| FWHT | XOR/AND/OR convolution |
| Subset convolution | complementary-subset convolution |

---

# Suggested learning priority at Codeforces 2200

## High practical return

1. HLD and virtual tree
2. Rollback DSU + offline dynamic connectivity
3. Monotone CHT, dynamic line container, and Li Chao differences
4. Wavelet matrix and persistent binary trie
5. Full segment tree beats
6. Rerooting DP and DSU on tree
7. Aho–Corasick, suffix automaton, Eertree
8. NTT, basic FPS, Berlekamp–Massey, Bostan–Mori
9. Rotating calipers and half-plane intersection
10. Tonelli–Shanks, floor sum, extended BSGS

## Learn after a motivating problem

- Link-cut tree
- Blossom
- Directed MST
- Dominator tree
- Gomory–Hu
- SMAWK
- Slope trick
- Du Jiao sieve
- Multipoint interpolation
- Subset convolution

A template is contest-ready only when you know:

1. its invariant;
2. the exact assumptions required;
3. the complexity;
4. one counterexample where it must not be used.
