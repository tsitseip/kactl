BOHDAN COMPETITIVE PROGRAMMING LIBRARY

This archive contains the three uploaded batches, reorganized by topic, plus newly written templates that fill the highest-value gaps.

STYLE USED FOR NEW FILES
- snippet-style C++ rather than complete programs
- compact structs and short method names: init/add/upd/get/build
- vectors and node structs similar to the uploaded templates
- half-open ranges [l,r) unless a file explicitly says otherwise
- only short prerequisite comments

IMPORTANT
- Original code was copied without editing its contents. Only filenames and folder paths were normalized.
- Some original snippets depend on your usual global template: bits/stdc++.h, using namespace std, N, mod, g, fi/se aliases, or an int -> long long macro.
- No test files were generated.
- Optimization templates require their mathematical preconditions; comments state the important ones.

MAIN GAPS FILLED
- HLD with path/subtree sum and maximum, LCA, node/edge mode
- SCC, Dinic, min-cost max-flow, centroid decomposition
- rollback DSU, DSU on tree, wavelet tree
- segment tree beats, persistent lazy tree, arithmetic-progression lazy tree, mergeable and iterative trees
- divide-and-conquer DP, Knuth optimization, monotone CHT, Aliens trick, SOS DP
- 2D geometry base, convex hull, point in convex polygon, Minkowski sum
- Aho-Corasick, suffix automaton, double rolling hash
- modint, non-coprime CRT, Pollard-Rho/Miller-Rabin, modular Gaussian elimination, Berlekamp-Massey
- clean NTT, arbitrary-mod convolution, FWHT, formal power series inverse/log/exp

Use 00 manifest.csv to see which files are user originals and which were added.

ADVANCED 2200+ EXTENSION
========================

This revision adds a second, non-duplicate layer aimed at Codeforces 2200-2500+:
- dynamic forests and difficult graph structure: link-cut tree, virtual tree,
  offline dynamic connectivity, dominator tree, directed MST, blossom,
  Stoer-Wagner and Gomory-Hu;
- advanced queries: wavelet matrix, persistent XOR trie, arbitrary-query CHT,
  segment Li Chao, disjoint sparse table and slope trick;
- stronger range structures: full segment-tree beats, historical maximum and
  a dynamic lazy segment tree;
- advanced DP: SMAWK, bitset LCS, generic rerooting and a complete WQS shell;
- geometry: half-plane intersection, rotating calipers and minimum enclosing circle;
- number theory: Tonelli-Shanks, extended BSGS, primitive roots, Du Jiao sieve,
  floor sum and divisor transforms;
- polynomial tools: FPS square root/power/division, multipoint
  evaluation/interpolation, Bostan-Mori, subset convolution and Taylor shift.

The original uploaded snippets remain unchanged. New files are marked
"added advanced" in 00 manifest.csv and listed separately in
00 advanced additions.csv.

Templates with explicit dependency comments should be pasted after the named
files. No test files are included in the archive.
