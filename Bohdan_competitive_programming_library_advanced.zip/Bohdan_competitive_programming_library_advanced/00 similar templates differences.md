# Similar templates: differences at a glance

This file is a condensed companion to `00 all added templates explained.md`.

## HLD vs link-cut tree vs centroid decomposition vs virtual tree

- **HLD:** static topology; path/subtree aggregates.
- **Link-cut tree:** topology changes online; link/cut/path aggregates.
- **Centroid decomposition:** static tree; dynamic distance-to-set queries.
- **Virtual tree:** static tree; many queries, each containing only a small marked set.

## Wavelet tree vs wavelet matrix vs persistent segment tree vs persistent trie

- **Wavelet tree/matrix:** static array; kth/rank/range frequency.
- **Persistent segment tree:** prefix versions; kth/count/general numeric ranges.
- **Persistent binary trie:** prefix versions; XOR-specific queries.
- Wavelet matrix is generally the cleaner advanced replacement for wavelet tree, but both solve the same main family.

## CHT choices

- **Monotone CHT:** use only when slopes and query `x` are monotone.
- **Dynamic line container:** arbitrary insertion/query order.
- **Li Chao:** arbitrary order over a coordinate domain; robust comparisons.
- **Segment Li Chao:** each line is valid only on part of the domain.

## DP optimization choices

- **Divide-and-conquer:** layered prefix DP and monotone opt.
- **Knuth:** interval DP and stronger opt bounds.
- **SMAWK:** totally monotone implicit matrix.
- **Aliens/WQS:** exact number of groups/items via penalty.
- **Slope trick:** the DP state itself is a convex piecewise-linear function.

## Segment tree choices

- **Ordinary lazy:** standard range add/assign.
- **Dynamic lazy:** huge sparse coordinates.
- **Persistent lazy:** query old versions after range updates.
- **Mergeable:** combine two sparse trees.
- **Beats partial:** add + chmin + sum.
- **Beats full:** add + chmin + chmax + sum/min/max.
- **Historical maximum:** remember the largest value ever reached.

## Flow and matching choices

- **Dinic:** maximum flow.
- **Min-cost max-flow:** flow plus cost.
- **Hungarian:** one-to-one assignment matrix.
- **Kuhn:** bipartite matching.
- **Blossom:** non-bipartite matching.
- **Stoer–Wagner:** one global undirected min-cut.
- **Gomory–Hu:** all pairwise undirected min-cuts.
- **Directed MST:** rooted directed arborescence.

## Polynomial choices

- **FFT:** floating-point ordinary convolution.
- **NTT:** exact convolution modulo a friendly prime.
- **Arbitrary-mod convolution:** several NTTs + CRT.
- **FPS basic:** inverse/log/exp.
- **FPS advanced:** sqrt/power/division.
- **Berlekamp–Massey:** discover a recurrence.
- **Bostan–Mori:** extract a huge coefficient from known `P/Q`.
- **Multipoint evaluation:** evaluate at many arbitrary points.
- **Taylor shift:** compute the entire polynomial after `x -> x+c`.
