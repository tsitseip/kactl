# Advanced additions: what they do and when to use them

This guide covers the 40 files listed in `00 advanced additions.csv`. The “example” for each item is a problem-recognition example, not a full implementation.

## 1. Graph theory

### 1. Directed MST / Chu–Liu–Edmonds
Finds a minimum-cost directed spanning arborescence rooted at a chosen vertex. Every other vertex receives exactly one incoming edge, and all vertices must be reachable from the root.

**Example:** Cities have directed flight offers with different costs. Choose the cheapest set of flights so every city is reachable from capital `0`.

**Do not confuse with:** Kruskal/Prim, which work on undirected graphs.

### 2. Dominator tree
In a directed graph rooted at `s`, vertex `u` dominates `v` when every path from `s` to `v` passes through `u`. The template returns the immediate dominator of every reachable vertex.

**Example:** In a control-flow graph, determine which program block must always execute before another block. In graph problems, find vertices whose removal blocks all routes from the source to some target.

### 3. General matching / Blossom
Finds a maximum matching in an arbitrary undirected graph, including odd cycles. Use it when the graph is not bipartite, so Kuhn/Hopcroft–Karp is invalid.

**Example:** Pair as many students as possible when compatibility is an arbitrary undirected relation and triangles may exist.

### 4. Gomory–Hu tree
Compresses all pairwise minimum cuts of an undirected weighted graph into one weighted tree using `n-1` max-flow computations. The minimum edge on the tree path between `u` and `v` equals their minimum cut value in the original graph.

**Example:** After preprocessing, answer many queries: “What is the minimum total capacity that must be removed to disconnect `u` from `v`?”

### 5. Link-cut tree
Maintains a dynamic forest. It supports linking two trees, cutting an existing edge, checking connectivity, changing a vertex value, and querying an aggregate such as sum or maximum on a path.

**Example:** Roads are added and removed while the graph must remain a forest; after each operation, query the maximum toll on the path from `u` to `v`.

**Typical API:** `link(u,v)`, `cut(u,v)`, `connected(u,v)`, `set_val(v,x)`, `get_path(u,v).sum` or `.mx`.

### 6. Offline dynamic connectivity
Answers connectivity queries when edges are added and removed over time. It places each edge on the time interval during which it exists, traverses a segment tree over time, and uses rollback DSU.

**Example:** Operations are `+ edge`, `- edge`, and `? u v`; print whether `u` and `v` are connected after every `?`.

**Important:** It is offline: all operations must be known before `solve()`.

### 7. Stoer–Wagner global minimum cut
Finds the minimum cut over every possible non-empty partition of an undirected weighted graph. Unlike max-flow, no source and sink are specified.

**Example:** Find the cheapest set of edges whose removal separates the network into any two non-empty components.

### 8. Virtual tree
Given a small set of important vertices in a large rooted tree, constructs the minimal compressed tree containing those vertices and the LCAs required to connect them. Its size is `O(k)` for `k` marked vertices.

**Example:** The original tree has `2e5` vertices, but each query marks only 30 vertices. Compute a DP involving distances or pair relationships only among those marked vertices.

---

## 2. Advanced data structures

### 9. Disjoint sparse table
Supports `O(1)` static range queries for any associative operation, including non-idempotent operations. It uses `O(n log n)` preprocessing and memory.

**Example:** Query the product of matrices `A[l] * A[l+1] * ... * A[r]` in the original order. Ordinary sparse table overlap would be invalid because matrix multiplication is not idempotent.

### 10. Dynamic line container
Maintains lines `y = kx + b` and answers maximum queries at arbitrary `x`, with both insertion and query in `O(log n)`. Slopes and query coordinates may arrive in any order.

**Example:** Optimize `dp[i] = max_j(dp[j] + m[j] * x[i])` online when neither slopes nor `x[i]` are monotone.

**For minimum:** Negate inserted lines and negate the answer.

### 11. Li Chao tree with segment insertion
Like a Li Chao tree, but each line is active only on a chosen x-coordinate interval. Query coordinates are compressed and supplied to `init()`.

**Example:** Offer `j` gives profit `k_j x + b_j`, but only for times `L_j <= x < R_j`. Query the best active offer at each requested time.

### 12. Persistent binary trie
Creates one trie version per prefix of the inserted sequence. By subtracting counts between two versions, it answers XOR-order queries on a subarray.

**Example:** For `a[L..R)`, find `max(a[i] XOR x)`, or count how many values satisfy `(a[i] XOR x) < k`.

### 13. Slope trick
Represents and updates a convex piecewise-linear function using two heaps. It is especially useful for DP objectives formed from absolute values and one-sided penalties.

**Example:** Choose nondecreasing values `x_i` minimizing `sum |x_i-a_i|`; or schedule events while minimizing total absolute movement cost.

**Recognition clue:** The DP state is a convex function, and transitions add terms such as `|x-a|`, `max(0,x-a)`, or shift the allowed argument interval.

### 14. Wavelet matrix
A static range-query structure for order statistics. It supports kth smallest, counting values below `x`, and counting values inside a value interval on an index interval.

**Example:** For each query `[l,r)`, return the 7th smallest number and the count of numbers in `[100,500)`.

**Typical cost:** `O(log sigma)` per query, where `sigma` is the number of distinct values.

---

## 3. Advanced segment trees

### 15. Dynamic lazy segment tree: range add + range sum
A lazy segment tree whose nodes are created only when visited, so it works on a huge coordinate range without coordinate compression.

**Example:** Coordinates reach `10^18`; add `v` to every integer position in `[l,r)` and query the sum over another interval, while only `O(q log C)` nodes are touched.

### 16. Historical maximum segment tree
Supports range additions and can query both the current maximum and the highest value that any position has ever reached during the entire update history.

**Example:** Scores receive positive and negative range adjustments. Query the current best score and the greatest score ever observed in `[l,r)`.

### 17. Full segment tree beats
Supports range `add`, range `chmin`, range `chmax`, and queries of sum, minimum, and maximum. It stores the first and second extrema and the number of occurrences of each extreme.

**Example:** Process operations such as:
- add 5 to `[l,r)`;
- replace every `a[i] > 10` by 10;
- replace every `a[i] < 3` by 3;
- query the range sum.

**Recognition clue:** Ordinary lazy propagation cannot easily compose `chmin/chmax` with sums, but the updates often affect only the current extreme values.

---

## 4. DP optimization and tree DP

### 18. SMAWK
Finds a minimum column for every row of an implicit totally monotone matrix in `O(rows + columns)` matrix evaluations.

**Example:** A DP transition matrix `cost(i,j)` is known to be totally monotone/Monge, and you need every row minimum without checking every pair.

**Important:** It is not valid for an arbitrary matrix; proving total monotonicity is the hard part.

### 19. WQS binary search
Also called Lagrangian relaxation and closely related to the Aliens trick. It converts an “exactly `k` components/groups” optimization into repeated unconstrained optimizations with a penalty `lambda` per group.

**Example:** Split an array into exactly `k` segments minimizing total segment cost. Solve `min(cost + lambda * number_of_segments)` and binary-search `lambda` until the chosen count crosses `k`.

### 20. Bitset LCS
Computes longest common subsequence length using word-parallel bit operations in roughly `O(|A||B|/64)`.

**Example:** Two strings each have length around `2e4`; quadratic LCS is too slow, but the alphabet is byte-sized and only the LCS length is required.

### 21. Generic rerooting DP
Computes a tree DP answer for every possible root in linear time, provided child contributions can be merged associatively and transferred across an edge.

**Example:** Find the sum of distances from every vertex to all other vertices, or the best subtree-based value when the tree is rooted at each vertex in turn.

**Core idea:** First compute child-to-parent contributions, then use prefix/suffix merges to send the contribution of “everything except this child” downward.

---

## 5. Geometry

### 22. Half-plane intersection
Intersects directed half-planes and returns the resulting convex polygon. Each directed line keeps the points on its left side.

**Example:** Find the feasible region satisfying linear inequalities such as `a_i x + b_i y <= c_i`, or clip a polygon by many lines.

**Important:** Add a large bounding box when the feasible intersection may be unbounded.

### 23. Minimum enclosing circle
Finds the smallest circle containing all points in expected `O(n)` time using randomized incremental construction.

**Example:** Place one radio tower with minimum required radius so that every given location is covered.

### 24. Rotating calipers diameter
Given a convex polygon in counter-clockwise order, finds its farthest pair of vertices in linear time.

**Example:** Compute the maximum squared distance between any two points: first build their convex hull, then run rotating calipers.

---

## 6. Strings

### 25. Duval algorithm / Lyndon factorization / minimum rotation
Splits a string into a non-increasing sequence of Lyndon words and can find the lexicographically smallest cyclic rotation in linear time.

**Example:** Among all rotations of `baca`, find the smallest one (`abac`), or use Lyndon factors in runs/string-periodicity arguments.

### 26. Palindromic tree / Eertree
Builds all distinct palindromic substrings online. Each node represents one distinct palindrome and stores its length, suffix link, transitions, and occurrence count.

**Example:** Count distinct palindromes, count occurrences of each palindrome, or maintain palindromic suffix information while characters are appended.

---

## 7. Algebra and optimization

### 27. Hungarian algorithm
Finds a minimum-cost matching between rows and columns of a cost matrix. Every vertex on the smaller side is matched.

**Example:** Assign `n` workers to `m` jobs so that each worker gets a distinct job and total cost is minimum.

**For maximum weight:** Negate costs or subtract them from a sufficiently large constant.

### 28. Matrix-tree theorem
Counts spanning trees of an undirected multigraph by taking a determinant of a Laplacian minor. The supplied template computes the answer modulo a prime.

**Example:** Count how many different spanning trees a graph has modulo `998244353`.

### 29. Rollback XOR basis
Maintains a linear basis over `GF(2)` with snapshots and rollback. It can return the maximum XOR obtainable from the currently inserted vectors.

**Example:** Values are active on time intervals. Add each value to segment-tree-over-time nodes, rollback after recursion, and answer maximum-subset-XOR queries at each time.

---

## 8. Number theory

### 30. Du Jiao sieve
Computes summatory multiplicative functions, especially `sum_{i<=n} phi(i)` and `sum_{i<=n} mu(i)`, for very large `n` by quotient grouping and memoization.

**Example:** `n` is around `10^11`, so sieving every value is impossible, but a formula requires the prefix sum of Euler phi or Möbius.

### 31. Tonelli–Shanks
Finds `x` such that `x^2 = n (mod p)` for an odd prime `p`, or reports that no solution exists.

**Example:** Solve `x^2 = 10 mod 13`; the algorithm returns one root, and the other is `p-x`.

### 32. Divisor zeta and Möbius transforms
Transforms arrays over the divisibility lattice. Multiple-based transforms are useful for gcd convolution; divisor-based transforms are useful for lcm convolution.

**Example:** Compute `c[g] = sum_{gcd(i,j)=g} a[i]b[j]` faster than trying all pairs.

### 33. Extended BSGS
Solves discrete logarithms `a^x = b (mod m)` even when `gcd(a,m) != 1`. It returns the smallest non-negative solution or `-1`.

**Example:** Find the first exponent `x` for which repeated multiplication by `a` reaches `b` modulo a composite number.

### 34. Floor sum
Computes
`sum_{0 <= i < n} floor((a*i+b)/m)`
using Euclidean-style reductions in logarithmic time.

**Example:** Count lattice points under a rational line or simplify a number-theoretic sum containing many floor divisions.

### 35. Primitive root modulo a prime
Finds a generator of the multiplicative group modulo prime `p`: a value `g` whose powers produce every non-zero residue.

**Example:** Construct an NTT for a suitable prime, enumerate multiplicative residues, or solve problems involving discrete logarithms and roots of unity.

---

## 9. FFT and polynomials

### 36. Bostan–Mori
Computes the coefficient `[x^k] P(x)/Q(x)` in `O(M(n) log k)`, where `M(n)` is polynomial multiplication time.

**Example:** Find the `10^18`-th term of a linear recurrence whose characteristic polynomial has moderate degree.

### 37. Taylor shift
Given coefficients of `f(x)`, computes coefficients of `f(x+c)` using convolution.

**Example:** Rewrite a polynomial around a new origin, or evaluate many derivatives/translated coefficients after shifting coordinates by `c`.

### 38. Advanced formal power series
Adds higher polynomial operations on top of NTT/FPS basics: polynomial square root, integer power, and fast polynomial division with remainder.

**Example:**
- find a series `g` with `g(x)^2 = f(x) mod x^n`;
- compute `f(x)^k mod x^n`;
- divide a large polynomial by another in near-linear time.

**Dependencies:** `NTT clean.txt` and `formal power series.txt`.

### 39. Multipoint evaluation and interpolation
Uses a product tree to evaluate a polynomial at many points, or reconstruct a polynomial from distinct `(x_i,y_i)` pairs, in near-linear time.

**Example:** Evaluate a degree-`2e5` polynomial at `2e5` points, where Horner’s method for every point would be quadratic.

### 40. Subset convolution
Computes
`c[S] = sum_{T subset S} a[T] * b[S\T]`
in `O(n^2 2^n)` for arrays indexed by masks of `n` bits.

**Example:** Combine two structures living on disjoint subsets—for each set `S`, split it into `T` and `S\T` and multiply their DP contributions.

---

# Recommended learning order at rating ~2200

## Learn first
1. Virtual tree
2. Offline dynamic connectivity + rollback DSU
3. Dynamic line container and segment Li Chao
4. Wavelet matrix and persistent binary trie
5. Full segment tree beats
6. Generic rerooting DP
7. Bitset LCS
8. Eertree and Duval
9. Half-plane intersection and rotating calipers
10. Tonelli–Shanks, extended BSGS, floor sum
11. Bostan–Mori and the basic FPS dependency chain

## Learn after seeing a motivating problem
1. Link-cut tree
2. Blossom
3. Directed MST
4. Dominator tree
5. Gomory–Hu and Stoer–Wagner
6. SMAWK
7. Slope trick
8. Du Jiao sieve
9. Multipoint interpolation and subset convolution

A template becomes contest-ready only after you can state its invariant, its valid input assumptions, and one situation where it must not be used.
